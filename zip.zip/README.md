Help me make a video speed controller chrome extension. It should go up to 5 times the normal speed of the video.
